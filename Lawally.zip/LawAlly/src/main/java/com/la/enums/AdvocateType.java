package com.la.enums;

public enum AdvocateType {
	
	BANKRUPTCY(0),
    CORPORATE(1),
    CONSTITUTIONAL(2),
    CRIMINAL_DEFENSE(3),
    EMPLOYMENT_AND_LABOR(4),
    ENTERTAINMENT(5),
    ESTATE_PLANNING(6),
    FAMILY(7),
    IMMIGRATION(8),
    INTELLECTUAL_PROPERTY(9),
    PERSONAL_INJURY(10),
    TAX(11);

    private final int value;

    AdvocateType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
    
    public static AdvocateType fromValue(int value) {
        for (AdvocateType specialization : values()) {
            if (specialization.value == value) {
                return specialization;
            }
        }
        throw new IllegalArgumentException("Unknown value: " + value);
    }
    
    public static AdvocateType fromString(String type) {
        for (AdvocateType specialization : values()) {
            if (specialization.name().equalsIgnoreCase(type)) {
                return specialization;
            }
        }
        throw new IllegalArgumentException("Unknown type: " + type);
    }
    
    
    
    
}
