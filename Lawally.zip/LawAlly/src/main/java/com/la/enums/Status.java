package com.la.enums;

public enum Status {
	CLOSED(0),
	OPEN(1),
	REQUESTED(2),
	SOLVED(3);
	
	private final int value;
	
	Status(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
