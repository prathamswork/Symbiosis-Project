package com.la;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LawAllyApplication {

	public static void main(String[] args) {
		SpringApplication.run(LawAllyApplication.class, args);
	}

}
