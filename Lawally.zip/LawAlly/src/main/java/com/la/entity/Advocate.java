package com.la.entity;

import java.util.HashSet;
import java.util.Set;

import com.la.enums.AdvocateType;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrimaryKeyJoinColumn;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@PrimaryKeyJoinColumn(name = "advocateId")
public class Advocate extends Auth {
	
	private String name;
	
	private String enrollmentNumber;
	
	private String city;
	
	private String locationState;
	
	private String imageUrl;
	
	private AdvocateType advocateType; 
	
	private int fees;
	
	@OneToMany(mappedBy = "advocate", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<Feedback> feedbacks = new HashSet<>(); 
	
	@OneToMany(mappedBy = "advocate", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Case> cases = new HashSet<>();

}
