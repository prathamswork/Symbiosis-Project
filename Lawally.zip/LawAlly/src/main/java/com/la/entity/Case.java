package com.la.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.la.enums.Status;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "`case`")
public class Case {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long caseId;
	
	
	@Column(nullable = false)
	private String description;
	
	@JsonIgnore
	@ManyToOne
    @JoinColumn(name = "client_id", referencedColumnName = "clientId", nullable = false)
    private Client client;
	
	@JsonIgnore
	@ManyToOne
    @JoinColumn(name = "advocate_id", referencedColumnName = "advocateId")
    private Advocate advocate;
	
	@Enumerated(EnumType.ORDINAL)
    @Column(name = "status")
	private Status status;
}
