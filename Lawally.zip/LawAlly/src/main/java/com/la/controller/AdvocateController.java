package com.la.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.la.dto.AdvocateDTO;
import com.la.dto.ClientDTO;
import com.la.entity.Advocate;
import com.la.entity.Client;
import com.la.services.AdvocateServices;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value="/api/advocate")
@CrossOrigin(origins = "http://localhost:3000")
public class AdvocateController {
	
	private AdvocateServices advocateServices;
	
	@Autowired
	public void setAdvocateServices(AdvocateServices advocateServices) {
		this.advocateServices = advocateServices;
	}
	
	//Client
	@GetMapping("/all")
	public ResponseEntity<List<Advocate>> getAllAdvocate(){
		return new ResponseEntity<List<Advocate>>(advocateServices.getAllAdvocate(), HttpStatus.OK);
	}
	
	@GetMapping("/{advocateId}")
	public ResponseEntity<Advocate> getAdvocateById(@PathVariable String advocateId){
		return new ResponseEntity<Advocate>(advocateServices.getAdvocateByAdvocateId(advocateId), HttpStatus.OK);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateAdvocate(@PathVariable String id, @Valid @RequestBody AdvocateDTO advocateDTO ) {
		return new ResponseEntity<String>(advocateServices.updateAdvocate(id, advocateDTO), HttpStatus.OK);
	}
	
	//Client
	@GetMapping("/all/sorted")
	public ResponseEntity<List<Advocate>> getAllAdvocateByFee(){
		return new ResponseEntity<List<Advocate>>(advocateServices.getAllAdvocatesSortedByFee(), HttpStatus.OK);
	}
	
	@GetMapping("/averageRating/{advId}")
	public ResponseEntity<String> averagerating(@PathVariable String advId){
		return new ResponseEntity<String>(advocateServices.getAverageRating(advId), HttpStatus.OK);
	}

}
