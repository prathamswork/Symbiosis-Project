package com.la.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.la.dto.AdvocateDTO;
import com.la.dto.AuthDTO;
import com.la.dto.ClientDTO;
import com.la.dto.JwtAuthResponse;
import com.la.dto.LoginDTO;
import com.la.services.AdvocateServices;
import com.la.services.AuthServices;
import com.la.services.ClientServices;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value="/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {
	
	private AuthServices authServices;
	
	@Autowired
	private ClientServices clientServices; 
	
	@Autowired
	private AdvocateServices advocateServices;
	
	@Autowired	
	public void setAuthServices(AuthServices authServices) {
		this.authServices = authServices;
	}

	@PostMapping("/client/register")
	public ResponseEntity<String> registerClient(@Valid @RequestBody ClientDTO clientDTO){
		return new ResponseEntity<>(clientServices.addClient(clientDTO), HttpStatus.CREATED);
	}
	
	@PostMapping("/advocate/register")
	public ResponseEntity<String> registerAdvocate(@Valid @RequestBody AdvocateDTO advocateDTO){
		return new ResponseEntity<>(advocateServices.addAdvocate(advocateDTO), HttpStatus.CREATED);
	}
	
	@PostMapping("/login")
	public ResponseEntity<JwtAuthResponse> login(@Valid @RequestBody LoginDTO loginDTO){
		
		JwtAuthResponse jwtAuthResponse = authServices.login(loginDTO);
		
		return new ResponseEntity<>(jwtAuthResponse,HttpStatus.ACCEPTED);
	}
	
}
