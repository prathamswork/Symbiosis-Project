package com.la.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.la.dto.ClientDTO;
import com.la.entity.Client;
import com.la.services.ClientServices;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value="/api/client")
@CrossOrigin(origins = "http://localhost:3000")
public class ClientController {
	
	private ClientServices clientServices;
	
	@Autowired	
	public void setClientServices(ClientServices clientServices) {
		this.clientServices = clientServices;
	}

	@GetMapping("/all")
	public ResponseEntity<List<Client>> getAllClients(){
		return new ResponseEntity<List<Client>>(clientServices.getAllClient(), HttpStatus.OK);
	}
	
	@GetMapping("/{clientId}")
	public ResponseEntity<Client> getClientById(@PathVariable String clientId){
		return new ResponseEntity<Client>(clientServices.getClientByClientId(clientId), HttpStatus.OK);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateClient(@PathVariable String id, @RequestBody ClientDTO clientDTO ) {
		return new ResponseEntity<String>(clientServices.updateClient(id, clientDTO), HttpStatus.OK);
	}
	
}
