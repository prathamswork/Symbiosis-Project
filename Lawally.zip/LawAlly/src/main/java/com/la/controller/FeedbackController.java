package com.la.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.la.dto.FeedbackDTO;
import com.la.entity.Feedback;
import com.la.services.FeedbackServices;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value="/api/feedback")
@CrossOrigin(origins = "http://localhost:3000")
public class FeedbackController {
	
	private FeedbackServices feedbackServices;
	
	@Autowired
	public void setFeedbackServices(FeedbackServices feedbackServices) {
		this.feedbackServices = feedbackServices;
	}
	
	//Client
	@PostMapping("/add/{caseId}")
	public ResponseEntity<String> addFeedbackForAdvocate(@PathVariable Long caseId, @Valid @RequestBody FeedbackDTO feedbackDTO){
		return new ResponseEntity<String>(feedbackServices.addFeedback(feedbackDTO, caseId),HttpStatus.CREATED);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateFeedback(@PathVariable Long id, @Valid @RequestBody FeedbackDTO feedbackDTO){
		return new ResponseEntity<String>(feedbackServices.updateFeedback(id, feedbackDTO),HttpStatus.CREATED);
	}
	
	//Advocate
	@GetMapping("/all/{advocateId}")
	public ResponseEntity<List<Feedback>> getAllFeedbackForAdvocate(@PathVariable String advocateId){
		return new ResponseEntity<List<Feedback>>(feedbackServices.getAllFeedbackByAdvocateId(advocateId),HttpStatus.OK);
	}

}
