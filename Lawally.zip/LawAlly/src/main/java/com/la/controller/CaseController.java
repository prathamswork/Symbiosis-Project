package com.la.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.la.dto.CaseAssignDTO;
import com.la.dto.CaseDTO;
import com.la.entity.Case;
import com.la.entity.Client;
import com.la.services.CaseServices;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value="/api/case")
@CrossOrigin(origins = "http://localhost:3000")
public class CaseController {
	
	private CaseServices caseServices;
	
	@Autowired
	public void setCaseServices(CaseServices caseServices) {
		this.caseServices = caseServices;
	}
	
	//Client
	@PostMapping("/add/{clientId}")
	public ResponseEntity<String> createCaseForClient(@Valid @RequestBody CaseDTO caseDtO, @PathVariable String clientId){
		return new ResponseEntity<String>(caseServices.addCase(caseDtO, clientId),HttpStatus.CREATED);
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Case>> getAllClients(){
		return new ResponseEntity<List<Case>>(caseServices.getAllCase(), HttpStatus.OK);
	}
	
	@GetMapping("/{caseId}")
	public ResponseEntity<Case> getClientById(@PathVariable Long caseId){
		return new ResponseEntity<Case>(caseServices.getCaseByCaseId(caseId), HttpStatus.OK);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateClient(@PathVariable Long id, @RequestBody CaseDTO caseDTO ) {
		return new ResponseEntity<String>(caseServices.updateCase(id, caseDTO), HttpStatus.OK);
	}
	
	//Client
	@GetMapping("/client/{clientId}")
	public ResponseEntity<List<Case>> getAllCasesByClientId(@PathVariable String clientId){
		return new ResponseEntity<List<Case>>(caseServices.getAllCasesByClientId(clientId), HttpStatus.OK);
	}
	
	// Advocate
	@GetMapping("/advocate/{advocateId}")
	public ResponseEntity<List<Case>> getAllCasesByAdvocateId(@PathVariable String advocateId){
		return new ResponseEntity<List<Case>>(caseServices.getAllCasesByAdvocateId(advocateId), HttpStatus.OK);
	}
	
	//Advocate
	@GetMapping("/requested/{advocateId}")
	public ResponseEntity<List<Case>> getAllCasesByAdvocateIdWithStatusRequested(@PathVariable String advocateId){
		return new ResponseEntity<List<Case>>(caseServices.getAllCaseWithStatusRequestedForAdvocate(advocateId), HttpStatus.OK);
	}
	
	//When Client Request Advocate
	@PutMapping("/requested")
	public ResponseEntity<String> requestCaseToAdvocate(@RequestBody CaseAssignDTO caseAssignDTO){
		return new ResponseEntity<String>(caseServices.requestCaseToAdvocate(caseAssignDTO.getCaseId(), caseAssignDTO.getAdvocateId()), HttpStatus.OK);
	}
	
	//When Advocate Accepts
	@PutMapping("/assign")
	public ResponseEntity<String> assignCaseToAdvocate(@RequestBody CaseAssignDTO caseAssignDTO){
		return new ResponseEntity<String>(caseServices.assignAdvocate(caseAssignDTO.getCaseId(), caseAssignDTO.getAdvocateId()),HttpStatus.CREATED);
	}
	
	//When Advocate Rejects
	@PutMapping("/reject/{caseId}")
	public ResponseEntity<String> rejectRequestFromCase(@PathVariable Long caseId){
		return new ResponseEntity<String>(caseServices.rejectCaseByAdvocate(caseId),HttpStatus.OK);
	}
	
	@GetMapping("/{caseId}/client")
	public ResponseEntity<Client> getClientForCase(@PathVariable Long caseId){
		return new ResponseEntity<Client>(caseServices.getClientByCaseId(caseId),HttpStatus.OK);
	}
	
	@PutMapping("/solved/{caseId}")
	public ResponseEntity<String> updateCaseAsSolved(@PathVariable Long caseId){
		return new ResponseEntity<String>(caseServices.updateCaseSolved(caseId),HttpStatus.OK);
	}
}
