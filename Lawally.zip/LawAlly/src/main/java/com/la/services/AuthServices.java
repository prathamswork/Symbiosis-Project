package com.la.services;

import com.la.dto.JwtAuthResponse;
import com.la.dto.LoginDTO;

public interface AuthServices {
	
	JwtAuthResponse login(LoginDTO loginDTO);
	
}
