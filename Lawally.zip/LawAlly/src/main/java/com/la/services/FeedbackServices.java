package com.la.services;

import java.util.List;

import com.la.dto.FeedbackDTO;
import com.la.entity.Feedback;

public interface FeedbackServices {

	String addFeedback(FeedbackDTO feedbackDTO, Long caseId);
	
	Feedback getFeedbackByFId(Long id);
	
	List<Feedback> getAllFeedback();
	
	String updateFeedback(Long id, FeedbackDTO feedbackDTO);
	
	List<Feedback> getAllFeedbackByAdvocateId(String advId);
	
}
