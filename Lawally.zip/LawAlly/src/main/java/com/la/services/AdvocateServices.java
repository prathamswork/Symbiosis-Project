package com.la.services;

import java.util.List;

import com.la.dto.AdvocateDTO;
import com.la.entity.Advocate;

public interface AdvocateServices {
	
	String addAdvocate(AdvocateDTO advocateDTO);
	
	List<Advocate> getAllAdvocate();
	
	Advocate getAdvocateByAdvocateId(String id);
	
	String updateAdvocate(String id, AdvocateDTO advocateDetails);
	
	List<Advocate> getAllAdvocatesSortedByFee();
	
	String getAverageRating(String advId);
	
}
