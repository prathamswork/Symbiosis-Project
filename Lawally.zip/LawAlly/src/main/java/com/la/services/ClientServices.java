package com.la.services;

import java.util.List;

import com.la.dto.ClientDTO;
import com.la.entity.Case;
import com.la.entity.Client;

public interface ClientServices {
	
	String addClient(ClientDTO clientDTO);
	
	List<Client> getAllClient();
	
	Client getClientByClientId(String id);
	
	String updateClient(String id, ClientDTO clientDetails);
	
}
