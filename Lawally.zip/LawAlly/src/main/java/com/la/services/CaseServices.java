package com.la.services;

import java.util.List;

import com.la.dto.CaseDTO;
import com.la.entity.Case;
import com.la.entity.Client;

public interface CaseServices {
	
	String addCase(CaseDTO caseDTO, String clientId);
	
	List<Case> getAllCase();
	
	Case getCaseByCaseId(Long id);
	
	String updateCase(Long id, CaseDTO caseDTO);
	
	List<Case> getAllCasesByClientId(String cltid);
	
	List<Case> getAllCasesByAdvocateId(String advId);
	
	String requestCaseToAdvocate(Long caseId, String advId);
	
	String assignAdvocate(Long caseId, String advId);
	
	String rejectCaseByAdvocate(Long caseId);
	
	List<Case> getAllCaseWithStatusRequestedForAdvocate(String advId);
	
	Client getClientByCaseId(Long caseId);
	
	String updateCaseSolved(Long caseId);
	
}
