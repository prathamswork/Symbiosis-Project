package com.la.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.la.entity.Verification;

@Repository
public interface VerificationRepository extends JpaRepository<Verification, String> {
	
	Optional<Verification> findByAdvocateName(String advocateName);
	
}
