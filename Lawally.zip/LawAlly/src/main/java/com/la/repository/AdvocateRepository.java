package com.la.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.la.entity.Advocate;

@Repository
public interface AdvocateRepository extends JpaRepository<Advocate, String>{
	
	List<Advocate> findAll(Sort sort);
	
}
