package com.la.servicesimpl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.la.dto.ClientDTO;
import com.la.entity.Client;
import com.la.entity.Role;
import com.la.repository.ClientRepository;
import com.la.repository.RoleRepository;
import com.la.services.ClientServices;

@Service
public class ClientServciesImpl implements ClientServices{
	
	private ClientRepository clientRepository;
	private RoleRepository roleRepository;
	
	private PasswordEncoder passwordEncoder;
	 
	@Autowired
	public void setClientRepository(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}
	
	@Autowired	
	public void setRolesRepository(RoleRepository roleRepository) {
		this.roleRepository = roleRepository;
	}
	
	@Autowired
	public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	public String addClient(ClientDTO clientDTO) {
		
		Client client = new Client();
		
		BeanUtils.copyProperties(clientDTO, client);
		client.setPassword(passwordEncoder.encode(clientDTO.getPassword()));
		
		//Assigning Role
		Set<Role> set = new HashSet<>();
		
		//Client Role
		Role role = roleRepository.findByName("ROLE_CLIENT");
		set.add(role);
		
		client.setRoles(set);
		
		//Saving to the database
		clientRepository.save(client);
		return "Client with userId: "+clientDTO.getUserId()+" added successfully";
	}

	@Override
	public List<Client> getAllClient() {
		return clientRepository.findAll();
	}

	@Override
	public Client getClientByClientId(String id) {
		return clientRepository.findById(id).orElseThrow(() -> new RuntimeException("Client with "+id+" not found"));
	}

	@Override
	public String updateClient(String id, ClientDTO clientDetails) {
		try {
            Optional<Client> optionalClient = clientRepository.findById(id);
            if (!optionalClient.isPresent()) {
                throw new RuntimeException("Client not found");
            }
            
            Client existingClient = optionalClient.get();
            if(clientDetails.getName()!=null)	existingClient.setName(clientDetails.getName());
            if(clientDetails.getContactNo()!=null)	existingClient.setContactNo(clientDetails.getContactNo());
            if(clientDetails.getAddress()!=null)	existingClient.setAddress(clientDetails.getAddress());
            
            clientRepository.save(existingClient);
            return "Client updated successfully";
        } catch (Exception e) {
            return "Failed to update client: " + e.getMessage();
        }
	}

}
