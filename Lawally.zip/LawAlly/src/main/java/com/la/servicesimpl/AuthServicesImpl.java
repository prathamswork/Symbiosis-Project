package com.la.servicesimpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.la.dto.JwtAuthResponse;
import com.la.dto.LoginDTO;
import com.la.entity.Auth;
import com.la.exception.UserNotFoundException;
import com.la.repository.AuthRepository;
import com.la.security.JwtTokenProvider;
import com.la.services.AuthServices;

@Service
public class AuthServicesImpl implements AuthServices{
	
	private AuthRepository authRepository;
	private AuthenticationManager authenticationManager;
	private JwtTokenProvider jwtTokenProvider;
	
	@Autowired
	public void setAuthRepository(AuthRepository authRepository) {
		this.authRepository = authRepository;
	}

	@Autowired
	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}
	
	@Autowired
	public void setJwtTokenProvider(JwtTokenProvider jwtTokenProvider) {
		this.jwtTokenProvider = jwtTokenProvider;
	}
	
	//Services Start Here...

	@Override
	public JwtAuthResponse login(LoginDTO loginDTO) {
		Optional<Auth> authOptional = authRepository.findByUserIdOrEmail(loginDTO.getUserIdOrEmail(), loginDTO.getUserIdOrEmail());
		
		if(authOptional.isEmpty()) {
			throw new UserNotFoundException(" User With Credential "+ loginDTO.getUserIdOrEmail() +" Not Found");
		}
		
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
						loginDTO.getUserIdOrEmail(),
						loginDTO.getPassword()
						));
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		String token = jwtTokenProvider.generateToken(authentication);
		
		String role = "ROLE_CLIENT";
		
		if(authOptional.isPresent()) {
			
			Auth loggedInUser = authOptional.get();
			Boolean isAdvocate = loggedInUser.getRoles().stream().anyMatch( r -> r.getName().equals("ROLE_ADVOCATE"));
			
			if(isAdvocate) role = "ROLE_ADVOCATE";
		}
		
		JwtAuthResponse jwtAuthResponse = new JwtAuthResponse();
		jwtAuthResponse.setAccessToken(token);
		jwtAuthResponse.setRole(role);
		
		return jwtAuthResponse;
	}

}
