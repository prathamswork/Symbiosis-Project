package com.la.servicesimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.la.dto.FeedbackDTO;
import com.la.entity.Advocate;
import com.la.entity.Case;
import com.la.entity.Feedback;
import com.la.repository.AdvocateRepository;
import com.la.repository.CaseRepository;
import com.la.repository.FeedbackRepository;
import com.la.services.FeedbackServices;

@Service
public class FeedbackServicesImpl implements FeedbackServices {
	
	private FeedbackRepository feedbackRepository;
	private AdvocateRepository advocateRepository;
	private CaseRepository caseRepository;
	 
	@Autowired	
	public void setFeedbackRepository(FeedbackRepository feedbackRepository) {
		this.feedbackRepository = feedbackRepository;
	}
	
	@Autowired
	public void setAdvocateRepository(AdvocateRepository advocateRepository) {
		this.advocateRepository = advocateRepository;
	}

	@Autowired
	public void setCaseRepository(CaseRepository caseRepository) {
		this.caseRepository = caseRepository;
	}

	
	@Override
	public String addFeedback(FeedbackDTO feedbackDTO, Long caseId) {
		
		Case existingCase = caseRepository.findById(caseId)
				.orElseThrow( () -> new RuntimeException("Case with "+caseId+" not found") );
		
		Advocate advocate = existingCase.getAdvocate();
		
		Feedback feedback = new Feedback();
		feedback.setFeedback(feedbackDTO.getFeedback());
		feedback.setRating(feedbackDTO.getRating());
		feedback.setAdvocate(advocate);
		
		feedbackRepository.save(feedback);
        return "Feedback added successfully";
	}

	@Override
	public Feedback getFeedbackByFId(Long id) {
		return feedbackRepository.findById(id).orElseThrow(() -> new RuntimeException("Feedback with "+id+" not found"));
	}

	@Override
	public List<Feedback> getAllFeedback() {
		return feedbackRepository.findAll();
	}

	@Override
	public String updateFeedback(Long id, FeedbackDTO feedback) {
		try {
            Optional<Feedback> optionalFeedback = feedbackRepository.findById(id);
            if (!optionalFeedback.isPresent()) {
                throw new RuntimeException("Feedback not found");
            }
            
            Feedback existingFeedback = optionalFeedback.get();
            existingFeedback.setFeedback(feedback.getFeedback());
            existingFeedback.setRating(feedback.getRating());
            
            feedbackRepository.save(existingFeedback);
            return "Feedback updated successfully";
        } catch (Exception e) {
            return "Failed to update feedback: " + e.getMessage();
        }
	}

	@Override
	public List<Feedback> getAllFeedbackByAdvocateId(String advId) {
		return feedbackRepository.findByAdvocateUserId(advId);
	}

}
