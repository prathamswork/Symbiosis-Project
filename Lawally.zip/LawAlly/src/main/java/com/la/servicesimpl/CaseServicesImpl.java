package com.la.servicesimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.la.dto.CaseDTO;
import com.la.entity.Advocate;
import com.la.entity.Case;
import com.la.entity.Client;
import com.la.enums.Status;
import com.la.repository.AdvocateRepository;
import com.la.repository.CaseRepository;
import com.la.repository.ClientRepository;
import com.la.services.CaseServices;

@Service
public class CaseServicesImpl implements CaseServices {
	
	private CaseRepository caseRepository;
	private ClientRepository clientRepository;
	private AdvocateRepository advocateRepository;
	
	@Autowired
	public void setCaseRepository(CaseRepository caseRepository) {
		this.caseRepository = caseRepository;
	}
	
	@Autowired
	public void setClientRepository(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Autowired
	public void setAdvocateRepository(AdvocateRepository advocateRepository) {
		this.advocateRepository = advocateRepository;
	}
	
	

	@Override
	@Transactional
	public String addCase(CaseDTO caseDTO, String clientId) {
		
		Client client = clientRepository.findById(clientId)
				.orElseThrow(() -> new IllegalArgumentException("Client not found"));

		Case newCase = new Case();
		newCase.setDescription(caseDTO.getDescription());
		newCase.setClient(client);
		newCase.setAdvocate(null);
		newCase.setStatus(Status.CLOSED);
		
		caseRepository.save(newCase);
		
		return "Case created Successfully";
	}

	@Override
	public List<Case> getAllCase() {
		
		List<Case> cases = caseRepository.findAll();
		
		return cases;
	}

	@Override
	public Case getCaseByCaseId(Long id) {
		
		Case case1 = caseRepository.findById(id).orElseThrow( () -> new RuntimeException("Case with "+id+" not found") );
		
		return case1;
	}

	@Override
	public String updateCase(Long id, CaseDTO case1) {
		 try {
	            // Find the existing case by id
	            Optional<Case> optionalCase = caseRepository.findById(id);
	            if (!optionalCase.isPresent()) {
	                throw new RuntimeException("Case not found");
	            }
	            
	            // Update the case with the new values
	            Case existingCase = optionalCase.get();
	            existingCase.setDescription(case1.getDescription());	            
	            
	            // Persist the updated case
	            caseRepository.save(existingCase);
	            
	            return "Case updated successfully";
	        } catch (Exception e) {
	            return "Failed to update case: " + e.getMessage();
	        }
	}

	@Override
	public List<Case> getAllCasesByClientId(String cltid) {
		return caseRepository.findByClientUserId(cltid);
	}

	@Override
	public List<Case> getAllCasesByAdvocateId(String advId) {
		return caseRepository.findByAdvocateUserId(advId);
	}

	@Override
	public String assignAdvocate(Long caseId, String advId) {
		
		
		Case existingCase = caseRepository.findById(caseId)
				.orElseThrow( () -> new RuntimeException("Case with "+caseId+" not found") );
		
		Advocate advocate = advocateRepository.findById(advId)
				.orElseThrow( () -> new RuntimeException("Case with "+advId+" not found") );
		
		existingCase.setDescription(existingCase.getDescription());
		existingCase.setClient(existingCase.getClient());
		existingCase.setAdvocate(advocate);
		existingCase.setStatus(Status.OPEN);
		
		caseRepository.save(existingCase);
		
		return "Case Assigned to Advocate";
	}

	@Override
	public String requestCaseToAdvocate(Long caseId, String advId) {
		Case existingCase = caseRepository.findById(caseId)
				.orElseThrow( () -> new RuntimeException("Case with "+caseId+" not found") );
		
		Advocate advocate = advocateRepository.findById(advId)
				.orElseThrow( () -> new RuntimeException("Case with "+advId+" not found") );
		
		
		existingCase.setDescription(existingCase.getDescription());
		existingCase.setClient(existingCase.getClient());
		existingCase.setAdvocate(advocate);
		existingCase.setStatus(Status.REQUESTED);
		
		caseRepository.save(existingCase);
		
		return "Case Requested to Advocate";
	}

	@Override
	public String rejectCaseByAdvocate(Long caseId) {
		Case existingCase = caseRepository.findById(caseId)
				.orElseThrow( () -> new RuntimeException("Case with "+caseId+" not found") );
		
		existingCase.setDescription(existingCase.getDescription());
		existingCase.setClient(existingCase.getClient());
		existingCase.setAdvocate(null);
		existingCase.setStatus(Status.CLOSED);
		
		caseRepository.save(existingCase);
		
		return "Case Rejected By Advocate";
	}

	@Override
	public List<Case> getAllCaseWithStatusRequestedForAdvocate(String advId) {
		
		List<Case> casesByAdvcoate = getAllCasesByAdvocateId(advId);
		
		List<Case> casesrequested = new ArrayList<>();
		
		for(Case case1: casesByAdvcoate) {
			if(case1.getStatus() == Status.REQUESTED) {
				casesrequested.add(case1);
			}
		}
		
		return casesrequested;
	}

	@Override
	public Client getClientByCaseId(Long caseId) {
		Case existingCase = caseRepository.findById(caseId)
				.orElseThrow( () -> new RuntimeException("Case with "+caseId+" not found") );
		
		
		return existingCase.getClient();
	}

	@Override
	public String updateCaseSolved(Long caseId) {
		Case existingCase = caseRepository.findById(caseId)
				.orElseThrow( () -> new RuntimeException("Case with "+caseId+" not found") );
		
//		existingCase.setDescription(existingCase.getDescription());
//		existingCase.setClient(existingCase.getClient());
//		existingCase.setAdvocate(existingCase.getAdvocate());
		existingCase.setStatus(Status.SOLVED);
		
		caseRepository.save(existingCase);
		
		return "Case Solved By Advocate";
	}

}
