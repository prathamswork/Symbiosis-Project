package com.la.servicesimpl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.la.dto.AdvocateDTO;
import com.la.entity.Advocate;
import com.la.entity.Feedback;
import com.la.entity.Role;
import com.la.entity.Verification;
import com.la.enums.AdvocateType;
import com.la.repository.AdvocateRepository;
import com.la.repository.RoleRepository;
import com.la.repository.VerificationRepository;
import com.la.services.AdvocateServices;

@Service
public class AdvocateServicesImpl implements AdvocateServices {
	
	private AdvocateRepository advocateRepository;
	private VerificationRepository verificationRepository;
	private RoleRepository roleRepository;
	
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	public void setAdvocateRepository(AdvocateRepository advocateRepository) {
		this.advocateRepository = advocateRepository;
	}
	
	@Autowired	
	public void setVerificationRepository(VerificationRepository verificationRepository) {
		this.verificationRepository = verificationRepository;
	}

	@Autowired	
	public void setRolesRepository(RoleRepository roleRepository) {
		this.roleRepository = roleRepository;
	}
	
	@Autowired
	public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	public String addAdvocate(AdvocateDTO advocateDTO) {
		
		Verification optionalVerification = verificationRepository.findById(advocateDTO.getEnrollmentNumber())
				.orElseThrow( () -> new RuntimeException("Advocate not found in Bar Counsil") );
		
		if ( !optionalVerification.getAdvocateName().equals(advocateDTO.getName()) ) {
            throw new RuntimeException("Advocate not found in Bar Counsil");
        }
		
		Advocate advocate = new Advocate();
		
		BeanUtils.copyProperties(advocateDTO, advocate);
		AdvocateType advType = AdvocateType.fromString(advocateDTO.getAdvocateType());
	    advocate.setAdvocateType(advType);
		advocate.setPassword(passwordEncoder.encode(advocateDTO.getPassword()));
		
		Set<Role> set = new HashSet<>();
		
		//Advocate Role
		Role role = roleRepository.findByName("ROLE_ADVOCATE");
		set.add(role);
		
		advocate.setRoles(set);
		
		advocateRepository.save(advocate);
        return "Advocate with userId: "+advocateDTO.getUserId()+" added successfully";
	}

	@Override
	public List<Advocate> getAllAdvocate() {
		return advocateRepository.findAll();
	}

	@Override
	public Advocate getAdvocateByAdvocateId(String id) {
		return advocateRepository.findById(id).orElseThrow(() -> new RuntimeException("Advocate with "+id+" not found"));
	}

	@Override
	public String updateAdvocate(String id, AdvocateDTO advocateDetails) {
		try {
            Optional<Advocate> optionalAdvocate = advocateRepository.findById(id);
            if (!optionalAdvocate.isPresent()) {
                throw new RuntimeException("Advocate not found");
            }
            
            Advocate existingAdvocate = optionalAdvocate.get();
            if(advocateDetails.getName()!=null)	existingAdvocate.setName(advocateDetails.getName());
            if(advocateDetails.getEnrollmentNumber()!=null)	existingAdvocate.setEnrollmentNumber(advocateDetails.getEnrollmentNumber());
            if(advocateDetails.getCity()!=null)	existingAdvocate.setCity(advocateDetails.getCity());
            if(advocateDetails.getLocationState()!=null)	existingAdvocate.setLocationState(advocateDetails.getLocationState());
            if(advocateDetails.getFees()!=0)	existingAdvocate.setFees(advocateDetails.getFees());
            
            advocateRepository.save(existingAdvocate);
            return "Advocate updated successfully";
        } catch (Exception e) {
            return "Failed to update advocate: " + e.getMessage();
        }
	}

	@Override
	public List<Advocate> getAllAdvocatesSortedByFee() {
		 return advocateRepository.findAll(Sort.by(Sort.Direction.ASC, "fee"));
	}

	@Override
	public String getAverageRating(String advId) {
		try {
            Optional<Advocate> optionalAdvocate = advocateRepository.findById(advId);
            if (!optionalAdvocate.isPresent()) {
                throw new RuntimeException("Advocate not found");
            }
            
            Advocate existingAdvocate = optionalAdvocate.get();
            
            Set<Feedback> feedbacks = existingAdvocate.getFeedbacks();
            
            Double count = 0.0;
            Double ratingSum = 0.0;
            for(Feedback feedback: feedbacks) {
            	++count;
            	ratingSum += feedback.getRating();
            }
            if(count == 0) {
            	return "No Rating";
            }
            else {
            	Double averageRating = ratingSum/count;
                
                String formattedAverageRating = String.format("%.1f", averageRating);
                
                return formattedAverageRating;
            }
            
        } catch (Exception e) {
            return e.getLocalizedMessage();
        }
	}

}
